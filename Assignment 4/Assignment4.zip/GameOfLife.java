// Christian Tonnesen
// 260847409

import java.util.Arrays;

public class GameOfLife {
  public static void main (String args[]) {
  }
  
  public static boolean isValidUniverse (int testedArray[][]) {
    int arraySize = testedArray[0].length;
    for (int index = 0; index < testedArray.length; index++) {
      if (!(arraySize == testedArray[index].length)) {
        return false;
      }
      
// The above for loop determines if all of the sub-arrays are the same size. If not, the boolean returns false
      
      for (int i = 0; i < testedArray[index].length; i++) {
        if (!((testedArray[index][i] == 0) || (testedArray[index][i] == 1))) {
          return false;
        }
        
//        The above for loop checks that all of the elements of the sub-arrays are either 1's or 0's and returns false
//        if otherwise
        
      }
    } 
    return true;
  }
  
  public static void displayUniverse (int [][] universe) {
    System.out.print('+');
    for (int index = 0; index < universe[0].length; index++) {
      System.out.print('-');
    }
    System.out.print('+');
    System.out.println();
    
    // The top row of the universe is created by placing a "+" and then creating as many "-" as there for the length
    // of the sub-array
    
    for (int index = 0; index < universe.length; index++) {
      System.out.print('|');
      for (int i = 0; i < universe[index].length; i++) {
        if (0 == universe[index][i]) {
          System.out.print(' ');
        }
        if (1 == universe[index][i]) {
          System.out.print('*');
        }
        
        // A double for loop prints the array row by row, using "*" in the case of 1's and using " " in the case of 
        // 0's
        
      }
      System.out.print('|');
      System.out.println();
      
      // Grid edges are printed at the beginning of the row loop and end of the row loop
      
    }
    System.out.print('+');
    for (int index = 0; index < universe[0].length; index++) {
      System.out.print('-');
    }
    System.out.print('+');
    System.out.println();
  }
  
  // The bottom row of "+" and "-" are made the same way as the top
  
  public static int getNextGenCell (int universe[][], int x, int y) {
    int aliveNeighbors = 0;
    aliveNeighbors += topLeftCheck (universe, x, y);
    aliveNeighbors += topMiddleCheck (universe, x, y);
    aliveNeighbors += topRightCheck (universe, x, y);
    aliveNeighbors += leftCheck (universe, x, y);
    aliveNeighbors += rightCheck (universe, x, y);
    aliveNeighbors += bottomLeftCheck (universe, x, y);
    aliveNeighbors += bottomMiddleCheck (universe, x, y);
    aliveNeighbors += bottomRightCheck (universe, x, y);
    
    // A variable of the amount of alive neighbors is initialized and is added to if there are any in the surrounding
    // cells. Each method analyzes the surrounding cells, starting in the top left and moving to the bottom right.
    
    if (universe[x][y] == 1) {
      if (aliveNeighbors < 2) {
        return 0;
      }
      if (aliveNeighbors == 2 || aliveNeighbors == 3) {
        return 1;
      } else {
        return 0;
      }
    }
    
    // The above conditions outline all of the rules for alive cells and return 0 or 1 depending on if the cell is
    // alive in the next generation
    
    if (universe[x][y] == 0) {
      if (aliveNeighbors == 3) {
        return 1;
      }
      
      // The above boolean accounts for if the cell will live to the next generation if it starts as dead
      
    }
    return 0;
  }
  
  // The below methods check all of surrounding cells to a chosen cell
  
  public static int topLeftCheck (int [][] universe, int x, int y) {
    if (x == 0 || y == 0){
      return 0;
    }
    
    // At the beginning of every "Check" method, there is a boolean to catch if the specified cell is a corner or
    // edge cell. In which case, to avoid an ArrayOutOfBounds exception, it returns a 0 before it ever gets indexed.
    
    if (universe[x-1][y-1] == 0) {
      return 0;
    } else {
      return 1;
    }
  }
  
  // A 1 is returned if the surrounding cell is alive or a 0 if it is dead. In this above case, the method is checking the 
  // top left cell.
  
  public static int topMiddleCheck (int universe[][], int x, int y) {
    if (x == 0) {
      return 0;
    }  
    if (universe[x-1][y] == 0) {
      return 0;
    } else {
      return 1;
    }  
  }
  
  public static int topRightCheck (int universe[][], int x, int y) {
    if (x == 0 || (y == (universe[x].length-1))){
      return 0;
    }
    if (universe[x-1][y+1] == 0) {
      return 0;
    } else {
      return 1;
    }
  }
  
  public static int leftCheck (int universe[][], int x, int y) {
    if (y == 0){
      return 0;
    } 
    if (universe[x][y-1] == 0) {
      return 0;
    } else {
      return 1;
    }
  }
  
  public static int rightCheck (int universe[][], int x, int y) {
    if (y == universe[x].length-1){
      return 0;
    }
    if (universe[x][y+1] == 0) {
      return 0;
    } else {
      return 1;
    }
  }
  
  public static int bottomLeftCheck (int universe[][], int x, int y) {
    if ((x == universe.length-1) || (y == 0)){
      return 0;
    }
    if (universe[x+1][y-1] == 0) {
      return 0;
    } else {
      return 1;
    }
  }
  
  public static int bottomMiddleCheck (int universe[][], int x, int y) {
    if (x == universe.length-1){
      return 0;
    }
    if (universe[x+1][y] == 0) {
      return 0;
    } else {
      return 1;
    }
  }
  
  public static int bottomRightCheck (int universe[][], int x, int y) {
    if (x == universe.length-1 || y == (universe[x].length-1)){
      return 0;
    }
    if (universe[x+1][y+1] == 0) {
      return 0;
    } else {
      return 1;
    }
  }
  
  public static int [][] getNextGenUniverse(int [][] prevUniverse) {
    int [][] nextUniverse = new int [prevUniverse.length][prevUniverse[0].length];
    for (int x = 0; x < prevUniverse.length; x++) {
      for (int y = 0; y < prevUniverse[0].length; y++) {
        nextUniverse [x][y] = getNextGenCell(prevUniverse, x, y);
      }
    }
    
    // The above method initializes a new array for the next generation of the length of the given generation. The new 
    // array is then populated cell by cell by using the getNextGenCell method on every cell of the previous generation
    
    return nextUniverse;
  }
  
  public static void simulateNGenerations (int [][] seedUniverse, int generations) {
    if (!(isValidUniverse(seedUniverse))) {
      throw new IllegalArgumentException ("Please input a valid universe");
    }     
    
    // The method throws an exception if the seed universe is not valid
    
    System.out.print("Original Seed");
    System.out.println();
    displayUniverse(seedUniverse);
    
    // The above lines display the starting seed
    
    for (int index = 1; index < generations+1; index++) {
      System.out.println("Generation " + index);
      seedUniverse = getNextGenUniverse(seedUniverse);
      displayUniverse(seedUniverse);
    }
    
    // The seed universe array is changed each time the for loop runs in order to bring it to the next iteration of
    // the loop, generating the next generation, etc.
    
  }
}










